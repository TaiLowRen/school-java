// Tyler Varlack
// 2/29/2019
// Exam II Program
// Using NetBeans and Scene Builder, create a JavaFX application with the a GUI.
package exam.iii;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author tylerman106
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private Button btnExit;
    @FXML
    private Button btnGo;
    @FXML
    private Label label1;
    @FXML
    private TextField txtName;
    @FXML
    private CheckBox chkBetter;
    @FXML
    private CheckBox chkSame;
    @FXML
    private Label label11;
    @FXML
    private Label resultLabel;
    @FXML
    private Label resultLabel1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void btnExitAction(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void btnGoAction(ActionEvent event) {
        String txt;
        txt = txtName.getText();
        resultLabel.setText(txt);

    }

    private String checkSelections() {
        String selections = "";
        if (chkBetter.isSelected() && chkSame.isSelected()) 
            selections += "is the same or better!";
         else if (chkBetter.isSelected()) 
            selections += "is better!";
        else if (chkSame.isSelected()) 
            selections += "is the same!";
         else 
            selections += "";
        return (selections);
    }

    private void updateResult(String selections) {
        String newResult = selections;
        resultLabel1.setText(newResult);
    }

    @FXML
    private void betterAction(ActionEvent event) {
        String betterselection = checkSelections();
        updateResult(betterselection);
    }

    @FXML
    private void sameAction(ActionEvent event) {
        String sameselection = checkSelections();
        updateResult(sameselection);
    }

}
