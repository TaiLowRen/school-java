/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wp;

/**
 *
 * @author tylerman106
 */
public class DigitData {
    private char digitInstance;
    private int digitCount;

    public DigitData() {
         this.digitCount = 1;
    }

    public DigitData(char digitInstance) {
        this.digitInstance = digitInstance;
    }

    public char getDigitInstance() {
        return digitInstance;
    }

    public int getDigitCount() {
        return digitCount;
    }
    public void incrementCount(){
        this.digitCount++ ;
       
    }
    @Override
    public String toString(){
        return null;
        
    }
}
