/*
Tyler Varlack
4/26/2019
WPA Program 2019
Intermediate Programming 
// I Got help but this is the best I could do with my current stress level
 */
package wp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        String FileName = "PI1000.txt"; // Edit this String to change the file
        File inFile; // retrieves the input File
        Scanner fileScanner;
        String fileLine;
        inFile = new File(FileName);
        ArrayList digitArrList = new ArrayList<>();
        digitArrList = loadDigitArrayList(inFile);
        DigitData[] pain = digitCountArray(digitArrList);
        
        try {
            fileScanner = new Scanner(inFile);
        } catch (FileNotFoundException ex) {
            System.out.println("It isn't there bud");

        }
        
        

    }

    public static ArrayList loadDigitArrayList(File inputFile) throws FileNotFoundException { // method for creating an ArrayList

        Scanner fileScanner;
        fileScanner = new Scanner(inputFile);
        ArrayList digitArr = new ArrayList<>();
        String pain = fileScanner.next();
        for (int i = 0; i < inputFile.length(); i++) {
            if (pain.charAt(i) >= '0' && pain.charAt(i) <= '9') {
                digitArr.add(pain.charAt(i));
            }
        }
        return digitArr;
    }

    public static DigitData[] digitCountArray(ArrayList charArray) { // method for creating DataDigit Objects
        DigitData[] digitDataArr;
        digitDataArr = new DigitData[10];
        for (int i = 0; i < charArray.size(); i++) {
            char currChar = (char) charArray.get(i);
            if (digitDataArr[currChar - '0'] != null) {
                digitDataArr[currChar - '0'].incrementCount();
            } else {
                digitDataArr[currChar = '0'] = new DigitData(currChar);
            }
        }
        return digitDataArr;
    }

    public static void outputTable(DigitData[] digitsFileCountArray) {
        // prints user interface
       
        System.out.println("******************************");
        System.out.println("**Digit Distribution for the**");
        System.out.println("**     first n #s of PI     **");
        System.out.println("** Digit Number of Occurancecs **");
        System.out.println("******************************");
        for (int i = 0; i < 10; i++) {
            // System.out.printf("|    %c                   %10\n" ,[i].(), [i].getDigitCount()); i got very lost at this point to be honest

        }
        
        System.out.println("******************************");
    }
}
    
