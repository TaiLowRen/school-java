/* 
 * Tyler Varlack
 * Exam 1 Program
 * 2/11/2019
 * A program that reads integers, finds the largets of them, and counts occurences
 */
package csc.pkg206.exam.pkg1.program;

import java.util.Scanner;

/**
 *
 * @author tylerman106
 */
public class CSC206Exam1Program {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declare Variables 
        int user = 0;
        int max = 0;
        int count = 1;
        String num = "";
        // Retrieve integer
        Scanner input = new Scanner(System.in);
        System.out.println("Enter numbers: ");
        user = input.nextInt();
        if (user >= 0) {
            num = user + num;
            max = (int) num.charAt(0);
        }
        if (max < user) {
            user = max;
            count = 1;
        } else if (max == user) {
            count++;
        }
        System.out.println("The largest number is " + max + " The occurrence count of the largest number is " + count);

        // Compare max with other integers
    }
}
