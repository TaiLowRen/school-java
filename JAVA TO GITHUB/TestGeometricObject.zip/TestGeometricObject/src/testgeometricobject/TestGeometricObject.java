/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testgeometricobject;

/**
 *
 * @author tylerman106
 */
public class TestGeometricObject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Circle anotherCircle = new Circle();
        Circle myCircle = new Circle(1);
        String theString = myCircle.toString();
        String theColor = myCircle.getColor();
        double theRadius = myCircle.getRadius();
        double theArea = myCircle.getArea();
        double theDiameter = myCircle.getDiameter();

        System.out.println("A myCircle " + theString);
        System.out.println("The color is " + theColor);
        System.out.println("The radius is " + theRadius);
        System.out.println("The area is " + theArea);
        System.out.println("The diameter is " + theDiameter);
        
         Square square = new Square(4);
        System.out.println("\nA square " + square.toString());
        System.out.println("The area is " + square.getArea());
        System.out.println("The perimeter is " + square.getPerimeter());

     RightTriangle triangle = new RightTriangle(3, 4, 5);
        System.out.println("\nA triangle " + triangle.toString());
        System.out.println("The area is " + triangle.getArea());
        System.out.println("The perimeter is " + triangle.getPerimeter());

         Rectangle rectangle = new Rectangle(4,5);
        System.out.println("\nA rectangle " + rectangle.toString());
        System.out.println("The area is " + rectangle.getArea());
        System.out.println("The perimeter is " + rectangle.getPerimeter());
        
        
        
        
    }

}
