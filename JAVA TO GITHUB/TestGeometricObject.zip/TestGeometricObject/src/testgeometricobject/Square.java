/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testgeometricobject;

/**
 *
 * @author tylerman106
 */
public class Square extends GeometricObject {

    double side;

    Square() {

    }

    Square(double side) {
        this.side = side;
    }

    Square(double side, String color, boolean filled) {
        this.side = side;
        super.setColor(color);
        setFilled(filled);
    }

    public double getSide() {
        return side;
    }

    void setSide() {
        this.side = side;
    }

    public double getArea() {
        return side * side;
    }

    public double getPerimeter() {
        return side + side + side + side;
    }

    @Override
    public String toString() {
        return "[Square] side = " + side;

    }

}
