/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testgeometricobject;

/**
 *
 * @author tylerman106
 */
public class RightTriangle extends GeometricObject {

    int base;
    int height;
    int c;

    RightTriangle() {
        
    }

    RightTriangle(int base, int height, int c) {
        this.base = base;
        this.height = height;
        this.c = c;

    }

    RightTriangle(int base, int height, String color, boolean filled) {
        this.base = base;
        this.height = height;
        super.setColor(color);
        setFilled(filled);
    }


    public int getBase() {
        return base;
    }

    void setBase() {
        this.base = base;
    }

    public int getHeight() {
        return height;
    }

    void setHeight() {
        this.height = height;
    }
    public int getC(){
        return c;
    }
     void setC() {
        this.c = c;
    }

    public double getArea() {
        return (.5) * base * height;
    }

    public double getPerimeter() {
        return base + height + Math.sqrt((base * base) + (height * height));
    }

    @Override
    public String toString() {
        String newToString = super.toString();
        newToString = newToString + " and base/height is " + base + height;
        return newToString;
    }

}
