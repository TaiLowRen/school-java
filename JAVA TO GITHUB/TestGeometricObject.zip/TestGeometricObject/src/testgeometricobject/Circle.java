/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testgeometricobject;

/**
 *
 * @author tylerman106
 */
public class Circle extends GeometricObject {

    private double radius;

    Circle() {
        
    }

    public Circle(double radius) {
        this.radius = radius;

    }

    public Circle(double radius, String color, boolean filled) {
        this.radius = radius;
        super.setColor(color);
        setFilled(filled);

    }

    /**
     * Get the radius for this circle
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Set a new radius for this circle
     */
     public void setRadius(double radius) {
        this.radius = radius;
    }

   public double getDiameter() {
        return radius * 2;
    }

   public double getArea() {
        return radius * radius * Math.PI;
    }

    public double getPerimeter() {
        return 2 * radius * Math.PI;
    }
   
}
