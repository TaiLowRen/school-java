/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testcelsiustemperature;

/**
 *
 * @author tylerman106
 */
public class TestCelsiusTemperature {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CelsiusTemperature TempBoi = new CelsiusTemperature();
        System.out.println(TempBoi.getCelsiusTemperature() + "C is " + TempBoi.ToFahrenheit() + "F and  " + TempBoi.toKelvin() + "K");

        TempBoi.setCelsiusTemperature(-40.0);
        System.out.println(TempBoi.getCelsiusTemperature() + "C is " + TempBoi.ToFahrenheit() + "F and  " + TempBoi.toKelvin() + "K");
        
         TempBoi.setCelsiusTemperature(100.0);
        System.out.println(TempBoi.getCelsiusTemperature() + "C is " + TempBoi.ToFahrenheit() + "F and  " + TempBoi.toKelvin() + "K");

    }

}
