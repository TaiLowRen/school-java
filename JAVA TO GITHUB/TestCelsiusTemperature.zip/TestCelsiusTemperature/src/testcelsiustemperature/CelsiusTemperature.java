/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testcelsiustemperature;

/**
 *
 * @author tylerman106
 */
public class CelsiusTemperature {
    private double temperatureCelsius;
    
    
     CelsiusTemperature(){
        
    }
     CelsiusTemperature(double temperatureCelsius){
        this.temperatureCelsius = 0;
    }
     public void setCelsiusTemperature(double temperatureCelsius){
         this.temperatureCelsius = temperatureCelsius;
     }
     public double getCelsiusTemperature(){
         return temperatureCelsius;
     }
     public double ToFahrenheit(){
         return (temperatureCelsius * 9.0/5.0 + 32.0);
     }
     public double toKelvin(){
         return temperatureCelsius + 273.0;
     }
    
}
