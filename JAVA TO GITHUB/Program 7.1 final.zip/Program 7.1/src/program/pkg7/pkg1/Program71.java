/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program.pkg7.pkg1;

/**
 *
 * @author tylerman106
 */
public class Program71 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] alpha = new int[26];
        String[] letter = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
        

        for (int i = 0; i < alpha.length; i++) {
            alpha[i] = i;
        }
        for (int i = 0; i < alpha.length; i++) {
            int index = (int) (Math.random() * alpha.length);
            int temp = alpha[i];
            alpha[i] = alpha[index];
            alpha[index] = temp;
        }
        for (int j = 16; j < 26; j++) {
            for (int i = 0; i < 10; i++) {
                String letters = letter[alpha[i]];
                System.out.print(letters);
                int index = (int) (Math.random() * alpha.length);
                int temp = alpha[i];
                alpha[i] = alpha[index];
                alpha[index] = temp;
            }
            System.out.println();
            j = (int) (Math.random() * alpha.length);
        }
    }
    public static int letterCounter (String str, char c) {
        int count = 0;

    for(int i=0; i < str.length(); i++)
    {    if(str.charAt(i) == c)
            count++;
    }

    return count;

        

}
}

