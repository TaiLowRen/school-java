/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dechexbinoct;

import java.util.Scanner;

/**
 *
 * @author tylerman106
 */
public class DecHexBinOct {

    /**
     * Main Method
     */
    public static void main(String[] args) {
        // Declare Variables

        int decimal;
        decimal = 0;
        String hexString = "";
        int hexValue;
        char hexDigit;
        String octString = "";
        int octValue;
        char octDigit;
        String binString = "";
        int binValue;
        char binDigit;

        System.out.println("Select (B)inary, (H)ex, or (O)ctal to begin: ");
        Scanner input = new Scanner(System.in);
        char base = input.next().charAt(0);
        if (base == 'H' || base == 'h') {
            System.out.println("Enter a decimal value: ");
            decimal = input.nextInt();
            while (decimal != 0) {
                hexValue = decimal % 16;
                if (hexValue <= 9 && hexValue >= 0) {
                    hexDigit = (char) (hexValue + '0');
                } else {
                    hexDigit = (char) (hexValue - 10 + 'A');
                }
                hexString = hexDigit + hexString;
                decimal = decimal / 16;
            }
            System.out.println("The hex number is " + hexString);
        } else if (base == 'B' || base == 'b') {
            System.out.println("Enter a decimal value: ");
            decimal = input.nextInt();
            while (decimal != 0) {
                binValue = decimal % 2;
                binDigit = (char) (binValue + '0');
                binString = binDigit + binString;
                decimal = decimal / 2;
            }
            System.out.println("The binary number is " + binString);
        } else if (base == 'O' || base == 'o') {
            System.out.println("Enter a decimal value: ");
            decimal = input.nextInt();
            while (decimal != 0) {
                octValue = decimal % 8;
                octDigit = (char) (octValue + '0');
                octString = octDigit + binString;
                decimal = decimal / 8;
            }
            System.out.println("The octal number is " + octString);
        } else {
            System.out.println("ENTER H B or O PLEASE!");
        }

    }

}
