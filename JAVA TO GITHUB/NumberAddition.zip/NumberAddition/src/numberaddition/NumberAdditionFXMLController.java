/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numberaddition;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author tylerman106
 */
public class NumberAdditionFXMLController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button btnExit;
    @FXML
    private Label label1;
    @FXML
    private Label labelResult;
    @FXML
    private Button btnAdd;
    @FXML
    private Button btnClear;
    @FXML
    private Label label11;
    @FXML
    private TextField txtFirstNumber;
    @FXML
    private TextField txtSecondNumber;
    @FXML
    private Label Result;
    @FXML
    private Button btnSub;
    
    @FXML
    private void btnExitAction(ActionEvent event) {
        System.exit(0);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnAddAction(ActionEvent event) {
        double num1,num2,result;
        num1 = Double.parseDouble(txtFirstNumber.getText());
        num2 = Double.parseDouble(txtSecondNumber.getText());
        result = num1 + num2;
        labelResult.setText(String.valueOf(result));
        
    }

    @FXML
    private void btnClearAction(ActionEvent event) {
        txtFirstNumber.setText("");
        txtSecondNumber.setText("");
        labelResult.setText("");
    }

    @FXML
    private void btnSubAction(ActionEvent event) {
         double num1,num2,result;
        num1 = Double.parseDouble(txtFirstNumber.getText());
        num2 = Double.parseDouble(txtSecondNumber.getText());
        result = num1 - num2;
        labelResult.setText(String.valueOf(result));
        
    }
    
}
