/*Author: Tyler Varlack
Date: 1/24/2019 
Assignment: Homework
Purpose: Reads and integer and adds all its didgets
 */
package program.pkg2.pkg6;

import java.util.Scanner;

/**
 *
 * @author Tyler
 */
public class Program26 {

  
    public static void main(String[] args) {
        // Declare variables and operations
     System.out.println("Enter your integer: ");
     Scanner input = new Scanner(System.in);
     int user = input.nextInt();
      int div;
        div = user / 10;
    int mod;
        mod = user % 10;
    int holder;
        holder = (div / 10) % 10;
    int div3, div4, div5;
        div3 = div % 10;
        div4 = (user / 1000) % 10;
        div5 = (user / 10000) % 100;
        
    int display; 
        display = div3 + mod + holder + div4 + div5;
        System.out.println(display);
}
    }
    
   
