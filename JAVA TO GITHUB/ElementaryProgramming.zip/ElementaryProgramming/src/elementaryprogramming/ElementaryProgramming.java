/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elementaryprogramming;

/**
 *
 * @author tylerman106
 */
public class ElementaryProgramming {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
Element hydrogen = new Element("Hydrogen" , "H", 1, 1.008);
Element oxygen = new Element();
Element nitrogen = new Element("Nitrogen" , "N", 7, 14.00674);
Element sodium = new Element("Sodium" , "Na", 11, 22.989758);
Element carbon = new Element("Carbon" , "C", 6, 12.011);

System.out.println(hydrogen.getName()
    + " has the symbol " + hydrogen.getSymbol()
            + ", atomic number " + hydrogen.getAtomicNumber()
            + ", atomic weight " + hydrogen.getAtomicWeight() );

    oxygen.setName("Oxygen");
    oxygen.setSymbol("O");
    oxygen.setAtomicNumber(8);
    oxygen.setAtomicWeight(15.999);
    
    System.out.println("Water has a chemical formula " 
    + "of H20 and a molecular weight of " 
    + (2 * hydrogen.getAtomicWeight() + oxygen.getAtomicWeight()));
    
    System.out.println(oxygen.getName()
    + " has the symbol " + oxygen.getSymbol()
            + ", atomic number " + oxygen.getAtomicNumber()
            + ", atomic weight " + oxygen.getAtomicWeight() );
    
    System.out.println("The molecular weight of Glucose is " 
            + ( 6 * carbon.getAtomicWeight()+ 
            + 12 * hydrogen.getAtomicWeight() + 
            + 6 * oxygen.getAtomicWeight() ) + " grams." );
    
       System.out.println("The molecular weight of Epinephrine is " 
            + (( 9 * carbon.getAtomicWeight())+ 
            + (13 * hydrogen.getAtomicWeight()) + 
            + nitrogen.getAtomicWeight() + ( 3 * oxygen.getAtomicWeight() ) ) + " grams." );
    
       System.out.println("The molecular weight of Acetic Acid is " 
            + (carbon.getAtomicWeight()+ 
            + 4 * hydrogen.getAtomicWeight() + 
            + (2 * oxygen.getAtomicWeight()) ) + " grams." );
    
       System.out.println("The molecular weight of Sodium Bicarbonate is " 
            + (carbon.getAtomicWeight()+ 
            + hydrogen.getAtomicWeight() + 
            + (3 * oxygen.getAtomicWeight()) + sodium.getAtomicWeight() ) + " grams." );
    
    
    
    

}

    }
    
    
