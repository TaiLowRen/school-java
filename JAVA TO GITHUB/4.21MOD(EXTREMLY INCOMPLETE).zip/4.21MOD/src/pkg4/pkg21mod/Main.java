/*Author: Tyler Varlack
 *Date: 2/5/2019
 *
 */
package pkg4.pkg21mod;

import java.util.Scanner;

/**
 *
 * @author tylerman106
 */
public class Main {
    public static void main(String[] args) {
     //Declare Variables / Retrieve SSN
     Scanner input = new Scanner(System.in);
     System.out.println("Enter your 9 SSN digets: ");
     String aN = input.next() + " ";    
     String gC = input.next() + " ";
     String sN = input.next() + " ";
     System.out.println("Enter your 9 SSN digets: ");
     //Validate SSN
     if(aN.equals(666)){
         System.out.println("Your Area Number is invalid");
     }
         else if(aN.equals(000)) {
                 System.out.println("Your Area Number is invalid");
            }
         else if(aN.contains("999")){
             System.out.println("Your Area Number is invalid");
            }
     else  System.out.println(aN); 
        
             
             
         
        
    }
     //Print SSN
    }
    

