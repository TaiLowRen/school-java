/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg8.pkg2;

/**
 *
 * @author Tyler
 */
public class Main {

    /**
     * @param args the command line arguments
     *
     */
    public static void main(String[] args) {
        int[][] matrix = new int[10][10];
        for (int row = 0; row < matrix.length; row++) {
            for (int column = 0; column < matrix[row].length; column++) {
                matrix[row][column] = (int) (Math.random() * 100);
            }
        }
        for (int row = 0; row < matrix.length; row++) {
            for (int column = 0; column < matrix[row].length; column++) {
                System.out.print(matrix[row][column] + " ");
            }
            System.out.println();

        }
averageNumber(matrix);
    }

    static double averageNumber(int[][] matrix) {
        double total = 0;
        for (int r = 0; r < matrix.length; r++) {
            for (int c = 0; c < matrix[r].length; c++) {
                total += (matrix[r][c]) / 100;
            }
        }
        return total;
    }
}
