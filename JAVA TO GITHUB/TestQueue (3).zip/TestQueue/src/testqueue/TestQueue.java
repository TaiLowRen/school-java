/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testqueue;

/**
 *
 * @author tylerman106
 */
public class TestQueue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyQueue queue = new MyQueue();

        System.out.println("isEmpty() returns : " + queue.isEmpty());
        System.out.println("getSize() returns : " + queue.getSize());

        for (int i = 0; i < 10; i++) {
            queue.enqueue(i);
        }
        System.out.println("isEmpty() returns : " + queue.isEmpty());
        System.out.println("getSize() returns : " + queue.getSize());
        System.out.println("peek() returns: " + queue.peek());

        while (!queue.isEmpty()) {
            System.out.print(queue.dequeue() + " ");
        }
        
        System.out.println("isEmpty() returns : " + queue.isEmpty());
        System.out.println("getSize() returns : " + queue.getSize());

    }

}
