/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testqueue;

/**
 *
 * @author tylerman106
 */
public class MyQueue {
    int[] item;
    int size;
    
    MyQueue(){
         item = new int[8];
    }
    void enqueue(int value){
                if (size >= item.length){
            int[] temp = new int[item.length * 2];
            for (int i = 0; i < item.length; i++){
                temp[i] = item[i];
            }
            item = temp;
        }
        item[size] = value;
        size++;
    }
    int dequeue(){
        
            int value = item[size - 1];
        size--;
        return value;
    }
    int peek(){
        return item[size -1];
    }
    boolean isEmpty(){
        return (size == 0);
    }
    int getSize(){
    return size;    
    }
    
    
    
}
