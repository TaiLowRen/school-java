/*
 * Tyler Varlack
 * 2/18/2019
 * Program 6.7
 * A program that calculates interest rate on future investments
 */
package program.pkg6.pkg7;

import java.util.Scanner;

/**
 *
 * @author tylerman106
 */
public class Program67 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double ia;
        double mir;
        System.out.println("Enter your investment amount: ");
        ia = input.nextDouble();
        System.out.println("Enter your interest rate: ");
        mir = input.nextDouble() /1200;
        System.out.println("Years              Future Value");
        for (int y = 1; y <= 30; y++) {
            System.out.printf("%-10d", y);
			System.out.printf("%11.2f\n", 
				futureInvestmentValue(ia, mir, y));
        }
    }

    public static double futureInvestmentValue(double investmentAmount, double monthlyInterestRate, int years) {
        return investmentAmount * Math.pow(1 + monthlyInterestRate, years * 12);
    }
}
